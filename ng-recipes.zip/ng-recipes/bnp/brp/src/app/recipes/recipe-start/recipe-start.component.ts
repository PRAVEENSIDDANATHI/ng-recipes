import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipe-start',
  templateUrl: './recipe-start.component.html',
  styles: []
})
export class RecipeStartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
