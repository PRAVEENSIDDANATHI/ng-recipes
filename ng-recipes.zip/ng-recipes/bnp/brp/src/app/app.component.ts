import { Component, OnInit } from '@angular/core';
import * as firebase from 'firebase';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  ngOnInit() {
    firebase.initializeApp({
      apiKey: "AIzaSyCP5jv5JOyUW1ydac_NEQEbSRtQwMbbXxo",
      authDomain: "ng-recipe-book-2fc52.firebaseapp.com"
    });
  }

}
